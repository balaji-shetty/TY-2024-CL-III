from django import forms
from ticket_booking.models import Ticket, Review  # Importing the necessary models

# Form for movie ticket booking
class movieForm(forms.ModelForm):
    class Meta:
        model = Ticket  # Reference to the Ticket model
        fields = ['movie_name', 'seat_number', 'theater']  # Fields to include in the form
        

# Form for submitting a review
class ReviewForm(forms.ModelForm):
    class Meta:
        model = Review  # Reference to the Review model
        fields = ['theater', 'feedback']  # Fields to include in the form
        widgets = {
            'theater': forms.Select(attrs={'class': 'form-control', 'placeholder': 'Select a theater'}),
            'feedback': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 4,
                'placeholder': 'Write your feedback here...'
            }),
        }