from django.shortcuts import render, get_object_or_404, redirect
from ticket_booking.models import Ticket, Theater, Payment, Review
from django.http import HttpResponse
from .forms import movieForm, ReviewForm  # Ensure you have a ReviewForm for handling reviews

# Home view
def home(request):
    if request.method == 'POST':
        
        form = movieForm(request.POST)
        if form.is_valid():
            ticket_booking = form.save(commit=False)
            ticket_booking.user = request.user
            ticket_booking.save()
            print(ticket_booking)
            return redirect('home')  # Redirect to avoid duplicate submissions
    else:
        form = movieForm()

    tickets = Ticket.objects.all()
    return render(request, 'home.html', {'form': form, 'tickets':tickets})

# Review view
def review(request):
    if request.method == 'POST':
        form = ReviewForm(request.POST)
        if form.is_valid():
            review = form.save(commit=False)
            review.user = request.user  # Assign the logged-in user
            review.save()
            return redirect('review')  # Redirect after saving the review to avoid resubmission
    else:
        form = ReviewForm()

    reviews = Review.objects.all()  # Fetch all reviews to display on the page
    return render(request, 'review.html', {'form': form, 'reviews': reviews})

def new(request):
    tickets = Ticket.objects.all() 
    return render(request, 'new.html',{'tickets': tickets})