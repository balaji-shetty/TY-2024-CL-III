from django.db import models

# Theater Model
class Theater(models.Model):
    name = models.CharField(max_length=100)
    location = models.CharField(max_length=255)

    def __str__(self):
        return self.name

# Ticket Model
class Ticket(models.Model):
    theater = models.ForeignKey('Theater', on_delete=models.CASCADE)
    movie_name = models.CharField(max_length=255)
    seat_number = models.CharField(max_length=10)

    def __str__(self):
        return f"{self.movie_name} - {self.seat_number}"

# Payment Model
class Payment(models.Model):
    ticket = models.ForeignKey(Ticket, on_delete=models.CASCADE)
    amount = models.DecimalField(max_digits=6, decimal_places=2)
    payment_date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Payment for {self.ticket.movie_name} ({self.amount} USD)"

# Review Model
class Review(models.Model):
    theater = models.ForeignKey(Theater, on_delete=models.CASCADE)
    feedback = models.TextField()

    def __str__(self):
        return f"Review for {self.theater.name}"

