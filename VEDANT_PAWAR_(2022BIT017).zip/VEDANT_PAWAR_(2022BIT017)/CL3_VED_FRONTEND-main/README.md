# Wedding_Planner
This website is designed and developed for wedding planners to showcase their services, portfolio, and testimonials from past clients. It is an online platform that allows wedding planners to promote their business, attract potential clients, and provide information about their services, pricing, and availability.
