from django.contrib import admin

# Register your models here.
from .models import User, Company, Job, Resume, Application

admin.site.register(User)
admin.site.register(Company)
admin.site.register(Job)
admin.site.register(Resume)

admin.site.register(Application)