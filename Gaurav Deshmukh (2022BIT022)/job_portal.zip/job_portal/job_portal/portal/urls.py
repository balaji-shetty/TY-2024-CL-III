from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('jobs/', views.job_list, name='job_list'),
    path('applications/', views.application_list, name='application_list'),
     path('application/', views.application_list, name='application_list_singular'),
]
