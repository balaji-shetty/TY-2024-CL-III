from django.shortcuts import render
from .models import Job, Application

def index(request):
    return render(request, 'portal/index.html')

def job_list(request):
    jobs = Job.objects.select_related('company').all()
    return render(request, 'portal/job_list.html', {'jobs': jobs})

def application_list(request):
    applications = Application.objects.select_related('user', 'job__company').all()
    return render(request, 'portal/application_list.html', {'applications': applications})


def company_list(request):
    companies = Company.objects.all()
    return render(request, 'portal/company_list.html', {'companies': companies})

def job_detail(request, job_id):
    job = Job.objects.get(id=job_id)
    return render(request, 'portal/job_detail.html', {'job': job})

def user_profile(request):
    user = request.user
    applications = Application.objects.filter(user=user)
    return render(request, 'portal/profile.html', {'user': user, 'applications': applications})


