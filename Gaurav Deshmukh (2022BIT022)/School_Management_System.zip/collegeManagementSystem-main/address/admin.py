from django.contrib import admin
from .models import District, Upazilla, Union


admin.site.register(District)
admin.site.register(Upazilla)
admin.site.register(Union)