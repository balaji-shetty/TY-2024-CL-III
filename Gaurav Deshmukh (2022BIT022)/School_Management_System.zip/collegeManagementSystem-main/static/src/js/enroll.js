// form visible
$('#enroll').on('click', function(){
    var roll = prompt('Set a Roll of This Student');
    var con = "{{ roll }}";
  });