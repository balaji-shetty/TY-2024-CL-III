import { useState } from 'react'

import './App.css'
import Card from './component/Card'
import Song from './component/song'

function App() {
  const [count, setCount] = useState(0)

  return (
   <>
    <Song/>
    
   </>
  )
}

export default App
